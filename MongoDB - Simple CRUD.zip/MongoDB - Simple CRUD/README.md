# MongoDB---Simple-CRUD
Heroku URL: <a href="https://nameless-depths-50060.herokuapp.com/">https://nameless-depths-50060.herokuapp.com/</a>
<h1>Department Managemnt</h1>
<ol>
    <li>Insert Department</li>
    <li>Update Department</li>
    <li>Delete Department</li>
    <li>Faetch All Department</li>
</ol>
<hr />
<img src="./postman/1.png" width="100%" />
<hr />
<img src="./postman/2.png" width="100%" />
<hr />
<img src="./postman/3.png" width="100%" />
<hr />
<img src="./postman/4.png" width="100%" />
<hr />
<img src="./postman/5.png" width="100%" />
<hr />
<img src="./postman/6.png" width="100%" />
<hr />
<img src="./postman/7.png" width="100%" />
<hr />
<img src="./postman/8.png" width="100%" />
<hr />

<h1>Employee Managemnt</h1>
<ol>
    <li>Insert Employee</li>
    <li>Update Employee</li>
    <li>Delete Employee</li>
    <li>Faetch All Employee</li>
</ol>
<hr />
<img src="./postman/9.png" width="100%" />
<hr />
<img src="./postman/10.png" width="100%" />
<hr />
<img src="./postman/11.png" width="100%" />
<hr />
<img src="./postman/12.png" width="100%" />
<hr />
<img src="./postman/13.png" width="100%" />
<hr />